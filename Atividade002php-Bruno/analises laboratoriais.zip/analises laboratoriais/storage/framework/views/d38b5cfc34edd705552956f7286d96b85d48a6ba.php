<?php $__env->startSection('titulo', 'Inserir Exame'); ?>

<?php $__env->startSection('conteudo'); ?>
	
	<br>
	<div class="container">
    	<div class="row justify-content-center">
        	<div class="col-md-6">
				<div class="card border-dark">
	                <div class="card-header bg-dark text-center text-light">
	                    Inserir Exame
	                </div>
	                <div class="card-body">
	                    <form method="POST" action="<?php echo e(route('tests.store')); ?>">
	                        <?php echo csrf_field(); ?>
	                        <div class="form-group row align-items-center">
	                            <label for="paciente" class="col-sm-3 col-form-label">Paciente</label>
	                            <div class="col-sm-9">
	                            	<?php if(Auth::user()->type == 1): ?>
	                            		<select class="form-control" name="user_id">
										<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            <?php if(Auth::user()->id == $user->id): ?>
								               	<option value="<?php echo e($user->id); ?>"selected> <?php echo e($user->name); ?></option>
								            <?php else: ?>
								               	<option value="<?php echo e($user->id); ?>"> <?php echo e($user->name); ?></option>
								           <?php endif; ?>
								        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								    <?php else: ?>
								    	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            <?php if(Auth::user()->id == $user->id): ?>
								               	<input class="form-control" type="text" name="name" id="price" disabled value="<?php echo e($user->name); ?>">
								           <?php endif; ?>
								        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								    <?php endif; ?>
								    </select>
	   	 						</div>
	                        </div>

	                        <div class="form-group row">
	                            <label for="price" class="col-sm-3 col-form-label">Exame</label>
	                            <div class="col-sm-9">
	                            	<select class="form-control" name="procedure_id">
		     							<?php $__currentLoopData = $procedures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									        <?php if(Auth::user()->id == $proc->id): ?>
									           	<option value="<?php echo e($proc->id); ?>"selected> <?php echo e($proc->name); ?></option>
									        <?php else: ?>
									            <option value="<?php echo e($proc->id); ?>"> <?php echo e($proc->name); ?></option>
									        <?php endif; ?>
									    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
	   	 						</div>
	                        </div>

	                        <div class="form-group row">
	                            <label for="date" class="col-sm-3 col-form-label">Data</label>
	                            <div class="col-sm-9">
	                            	<input class="form-control" type="date" name="date" id="date">
	   	 						</div>
	                        </div>
	                </div>
	                <div class="card-footer bg-secondary border-dark text-right">
	                	<div class="float-right">
	                    	<a class="btn btn-info" role="button" aria-pressed="true" href=<?php echo e(route('tests.index')); ?>>Voltar</a>
	                    	<button type="submit" class="btn btn-success">Inserir</button>
	                    </form>
						</div>
	                </div>
            	</div>
          	</div>
        </div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Usuários\Gabriel\Documentos\GitHub\2019-01-atividades-Gabriel-Reis\CSI477-2019-01-atividade-pratica-002-PHP-NEW\resources\views/tests/create.blade.php ENDPATH**/ ?>