

<?php $__env->startSection('titulo', 'Procedimentos'); ?>

<?php $__env->startSection('conteudo'); ?>

	<div class="p-3 mb-2 container mt-4">
	<div>
		<h2>Relação de Procedimentos</h2>
	</div>
		<table class="table table-striped table-bordered table-hover table-sm table-responsive-sm">
		<thead>
		<tr>
			<th>Nome</th>
			<th>Preço</th>
			<th>Resposável</th>
			<th>Ação</th>
		</tr>
		</thead>

		<?php $__currentLoopData = $procedures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td> <?php echo e($p->name); ?> </td>
				<td> <?php echo e($p->price); ?> </td>
				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($p->user_id == $u->id): ?>
						<td> <?php echo e($u->name); ?> </td>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<td><a href="<?php echo e(route('procedures.show', $p->id )); ?>">Exibir</a></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>

	<div class="float-right">
		<a class="btn btn-outline-success" role="button" aria-pressed="true" href=<?php echo e(route('procedures.create')); ?>>Novo procedimento</a>
	</div>

	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bc/Área de Trabalho/analises laboratoriais/resources/views/procedures/index.blade.php ENDPATH**/ ?>