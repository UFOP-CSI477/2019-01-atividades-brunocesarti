

<?php $__env->startSection('titulo', 'Exame'); ?>

<?php $__env->startSection('conteudo'); ?>

	<div class="p-3 mb-2 container mt-4">
	<div>
		<h2>Área do Paciente</h2>
	</div>
		<table class="table table-striped table-bordered table-hover table-sm table-responsive-sm">
		<thead>
		<tr>
			<th>Paciente</th>
			<th>Procedimento</th>
			<th>Preço</th>
			<th>Data</th>
			<th>Ação</th>
		</tr>
		</thead>

		<?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(Auth::check()): ?>
				<?php if($t->user_id == Auth::user()->id || Auth::user()->type == 1): ?>
					<tr>
						<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($t->user_id == $u->id): ?>
								<td> <?php echo e($u->name); ?> </td>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php $__currentLoopData = $procedures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($t->procedure_id == $pd->id): ?>
								<td> <?php echo e($pd->name); ?> </td>
								<td> <?php echo e($pd->price); ?> </td>
								<?php
									$price = $price + $pd->price;
									$count = $count + 1;
								?>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<td> <?php echo e($t->date); ?> </td>
						<td><a href="<?php echo e(route('tests.show',$t->id)); ?>">Exibir</a></td>
					</tr>
				<?php endif; ?>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<tfoot>
			<tr class="table-success">
				<td colspan="4" class="font-weight-bold">
					Total de exames:
				</td>
				<td colspan="1" class="text-right font-weight-bold">
					<?php echo e($count); ?>

				</td>
			</tr>
			<tr class="table-success">
				<td colspan="4" class="font-weight-bold">
					Preço Total:
				</td>
				<td colspan="1" class="text-right font-weight-bold">
					<?php echo e($price); ?>

				</td>
			</tr>
		</tfoot>

		</table>

		<div class="float-right">
			<a class="btn btn-outline-success" role="button" aria-pressed="true" href=<?php echo e(route('tests.create')); ?>>Marcar Exame</a>
		</div>

	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bc/Área de Trabalho/analises laboratoriais/resources/views/tests/index.blade.php ENDPATH**/ ?>