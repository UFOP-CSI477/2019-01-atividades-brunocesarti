<?php $__env->startSection('conteudo'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Usuários\Gabriel\Documentos\GitHub\2019-01-atividades-Gabriel-Reis\CSI477-2019-01-atividade-pratica-002-PHP-NEW\resources\views/home.blade.php ENDPATH**/ ?>