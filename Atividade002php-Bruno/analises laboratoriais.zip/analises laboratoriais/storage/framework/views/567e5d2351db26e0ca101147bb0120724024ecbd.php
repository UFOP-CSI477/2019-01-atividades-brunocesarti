

<?php $__env->startSection('titulo','Editar Exame'); ?>

<?php $__env->startSection('conteudo'); ?>

	<br>
	<div class="container">
    	<div class="row justify-content-center">
        	<div class="col-md-6">
				<div class="card border-success">
	                <div class="card-header bg-success text-center text-light">
	                    Atualizar Exame
	                </div>
	                <div class="card-body">
	                    <form method="post" action="<?php echo e(route('tests.update', $test->id)); ?>">
							<?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
							<div class="form-group row align-items-center">
	                            <label for="name" class="col-sm-3 col-form-label">Paciente</label>
	                            <div class="col-sm-9">
	                            	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							            <?php if( $test->user_id == $u->id): ?>

	     									<?php if(Auth::user()->type!=1): ?>
	     										<input class="form-control" id ="name" type="text" name="name" disabled value="<?php echo e($u->name); ?>">
	     									<?php else: ?>
	     										<select class="form-control" name="user_id">
													<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											            <?php if(Auth::user()->id == $u->id): ?>
											               	<option value="<?php echo e($u->id); ?>"selected> <?php echo e($u->name); ?></option>
											            <?php else: ?>
											               	<option value="<?php echo e($u->id); ?>"> <?php echo e($u->name); ?></option>
											           <?php endif; ?>
											        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											       </select>
	     									<?php endif; ?>
							            <?php endif; ?>
							        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	   	 						</div>
	                        </div>
	                        <div class="form-group row align-items-center">
	                            <label for="name" class="col-sm-3 col-form-label">Exame</label>
	                            <div class="col-sm-9">
	     							<select class="form-control" name="procedure_id">
							            <?php $__currentLoopData = $procedures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							            	<option value="<?php echo e($p->id); ?>"
							                <?php if( $test->procedure_id == $p->id): ?>
							                	selected
							                <?php endif; ?>
							                > <?php echo e($p->name); ?></option>
							            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							        </select>
	   	 						</div>
	                        </div>
	                        <div class="form-group row align-items-center">
	                            <label for="name" class="col-sm-3 col-form-label">Data</label>
	                            <div class="col-sm-9">
	     							<input class="form-control" id ="name" type="date" name="date" value=<?php echo e($test->date); ?>>
	   	 						</div>
	                        </div>
	                </div>
	                <div class="card-footer bg-secondary border-success text-right">
	                	<div class="float-right">
	                		<a class="btn btn-primary btn" role="button" aria-pressed="true" href=<?php echo e(route('tests.show', $test->id )); ?>>Voltar</a>
							<input class="btn btn-success" type="submit" name="btnSalvar" value="Atualizar">
							</form>
						</div>
	                </div>
            	</div>
          	</div>
        </div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bc/Área de Trabalho/analises laboratoriais/resources/views/tests/edit.blade.php ENDPATH**/ ?>