<?php $__env->startSection('titulo', 'Procedimentos'); ?>

<?php $__env->startSection('conteudo'); ?>
	
	<div class="p-3 mb-2 container mt-4">
		
		<table class="table table-striped table-bordered table-hover table-sm table-responsive-sm">
		<thead class="thead-dark">
		<tr>
			<th>Nome</th>
			<th>Preço</th>
			<th>Resposável</th>
			<th>Visualizar</th>
		</tr>
		</thead>

		<?php $__currentLoopData = $procedures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td> <?php echo e($proc->name); ?> </td>
				<td> <?php echo e($proc->price); ?> </td>
				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($proc->user_id == $user->id): ?>
						<td> <?php echo e($user->name); ?> </td>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<td><a href="<?php echo e(route('procedures.show', $proc->id )); ?>">Visualizar</a></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>

	<div class="float-right">
		<a class="btn btn-dark btn-lg active" role="button" aria-pressed="true" href=<?php echo e(route('procedures.create')); ?>>Inserir procedimento</a>
	</div>

	</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Usuários\Gabriel\Documentos\GitHub\2019-01-atividades-Gabriel-Reis\CSI477-2019-01-atividade-pratica-002-PHP\resources\views/procedures/index.blade.php ENDPATH**/ ?>