<?php $__env->startSection('titulo','Exibir Procedimento'); ?>

<?php $__env->startSection('conteudo'); ?>

	<br>
	<div class="container">
    	<div class="row justify-content-center">
        	<div class="col-md-6">
				<div class="card border-dark">
	                <div class="card-header bg-dark text-center text-light">
	                    <label><?php echo e($procedures->name); ?></label>
	                </div>
	                <div class="card-body">
	                	<div class="list-group">
	                		<label class="list-group-item d-flex justify-content-between align-items-center list-group-item-action list-group-item-secondary">Preço: <?php echo e($procedures->price); ?> </label>

							<label class="list-group-item d-flex justify-content-between align-items-center list-group-item-action list-group-item-secondary">Criador: 
								<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($procedures->user_id == $user->id): ?>
										<td> <?php echo e($user->name); ?> </td>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
	                <div class="card-footer bg-secondary border-dark text-right">
	                	<div class="d-flex justify-content-end">
	                	<a class="btn btn-success btn-sm mr-2" role="button" aria-pressed="true" href=<?php echo e(route('procedures.index')); ?>>Voltar</a>
	                	<a class="btn btn-info btn-sm mr-2" role="button" aria-pressed="true" href=<?php echo e(route('procedures.edit',$procedures->id)); ?>>Editar</a>
	                	<?php
							$bool = True;
		                	foreach ($tests as $test)
		                		if ($test->procedure_id == $procedures->id)
									$bool = False;
	                	?>
	                	<?php if($bool == True): ?>
	                		<form id="logout-form" method="post" action="<?php echo e(route('procedures.destroy',$procedures->id)); ?>" onsubmit="return confirm('cofirma exclusão do exame?');">
								<?php echo csrf_field(); ?>
								<?php echo method_field('DELETE'); ?>
								<input class="btn btn-danger btn-sm" type="submit" value="Excluir">
							</form>
						<?php endif; ?>
						
	                </div>
            	</div>
          	</div>
        </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Usuários\Gabriel\Documentos\GitHub\2019-01-atividades-Gabriel-Reis\CSI477-2019-01-atividade-pratica-002-PHP-NEW\resources\views/procedures/show.blade.php ENDPATH**/ ?>