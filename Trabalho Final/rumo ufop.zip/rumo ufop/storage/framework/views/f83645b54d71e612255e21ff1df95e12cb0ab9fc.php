

<?php $__env->startSection('titulo','Editar Procedimento'); ?>

<?php $__env->startSection('conteudo'); ?>

	<br>
	<div class="container">
    	<div class="row justify-content-center">
        	<div class="col-md-6">
				<div class="card border-success">
	                <div class="card-header bg-success text-center text-light">
	                    Atualizar Procedimento
	                </div>
	                <div class="card-body">
	                    <form method="post" action="<?php echo e(route('procedures.update', $procedure->id)); ?>">
							<?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
							<div class="form-group row align-items-center">
	                            <label for="name" class="col-sm-2 col-form-label">Nome</label>
	                            <div class="col-sm-10">
	     							<input class="form-control" id ="name" type="text" name="name" value=<?php echo e($procedure->name); ?>>
	   	 						</div>
	                        </div>
	                        <div class="form-group row align-items-center">
	                            <label for="name" class="col-sm-2 col-form-label">Nome</label>
	                            <div class="col-sm-10">
	     							<input class="form-control" id ="price" type="text" name="price" value=<?php echo e($procedure->price); ?>>
	   	 						</div>
	                        </div>
	                </div>
	                <div class="card-footer bg-secondary border-success text-right">
	                	<div class="float-right">
	                		<a class="btn btn-primary btn active" role="button" aria-pressed="true" href=<?php echo e(route('procedures.show', $procedure->id )); ?>>Voltar</a>
							<input class="btn btn-success" type="submit" name="btnSalvar" value="Atualizar">
							</form>
						</div>
	                </div>
            	</div>
          	</div>
        </div>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bc/Área de Trabalho/analises laboratoriais/resources/views/procedures/edit.blade.php ENDPATH**/ ?>