<?php $__env->startSection('titulo', 'Exame'); ?>

<?php $__env->startSection('conteudo'); ?>
	
	<div class="p-3 mb-2 container mt-4">

		<table class="table table-striped table-bordered table-hover table-sm table-responsive-sm">
		<thead class="thead-dark">
		<tr>
			<th>Paciente</th>
			<th>Procedimento</th>
			<th>Preço</th>
			<th>Data</th>
			<th>Visualizar</th>
		</tr>
		</thead>

		<?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($p->user_id == Auth::user()->id || Auth::user()->type == 1): ?>
				<tr>
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($p->user_id == $user->id): ?>
							<td> <?php echo e($user->name); ?> </td>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $procedures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($p->procedure_id == $proc->id): ?>
							<td> <?php echo e($proc->name); ?> </td>
							<td> <?php echo e($proc->price); ?> </td>
							<?php
								$price = $price + $proc->price;
								$count = $count + 1;
							?>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<td> <?php echo e($p->date); ?> </td>
					<td><a href="<?php echo e(route('tests.show',$p->id)); ?>">Visualizar</a></td>
				</tr>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
		<tfoot>
			<tr>
				<td colspan="4" class="bg-dark text-white font-weight-bold">
					Total de exames:
				</td>
				<td colspan="1" class="bg-dark text-white text-right font-weight-bold">
					<?php echo e($count); ?>	
				</td>
			</tr>
			<tr>
				<td colspan="4" class="bg-dark text-white font-weight-bold">
					Preço Total: 
				</td>
				<td colspan="1" class="bg-dark text-white text-right font-weight-bold">
					<?php echo e($price); ?>

				</td>
			</tr>
		</tfoot>

		</table>
		
		<div class="float-right">
			<a class="btn btn-dark btn-lg active" role="button" aria-pressed="true" href=<?php echo e(route('tests.create')); ?>>Inserir teste</a>
		</div>

	</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Usuários\Gabriel\Documentos\GitHub\2019-01-atividades-Gabriel-Reis\CSI477-2019-01-atividade-pratica-002-PHP-NEW\resources\views/tests/index.blade.php ENDPATH**/ ?>