<?php $__env->startSection('titulo', 'Usuários'); ?>

<?php $__env->startSection('conteudo'); ?>
	
	<div class="p-3 mb-2 container mt-4">

		<table class="table table-striped table-bordered table-hover table-sm table-responsive-sm">
		<thead class="thead-dark">
		<tr>
			<th>Nome</th>
			<th>Email</th>
			<th>Tipo</th>
			<th>Editar</th>
		</tr>
		</thead>

		<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td> <?php echo e($p->name); ?> </td>
				<td> <?php echo e($p->email); ?> </td>
				<?php if($p->type==1): ?>
					<td> Administrador </td>
				<?php elseif($p->type==2): ?>
						<td> Operador </td>
				<?php elseif($p->type==3): ?>
						<td> Paciente </td>
				<?php endif; ?>
				<td><a href="<?php echo e(route('users.show',$p->id)); ?>">Exibir</a></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>

		<div class="float-right">
			<a class="btn btn-dark btn-lg active" role="button" aria-pressed="true" href=<?php echo e(route('users.create')); ?>>Inserir usuário</a>
		</div>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Usuários\Gabriel\Documentos\GitHub\2019-01-atividades-Gabriel-Reis\CSI477-2019-01-atividade-pratica-002-PHP-NEW\resources\views/users/index.blade.php ENDPATH**/ ?>