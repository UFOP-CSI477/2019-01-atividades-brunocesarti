<?php $__env->startSection('titulo', 'Inserir Procedimento'); ?>

<?php $__env->startSection('conteudo'); ?>
	
	<br>
		
	<div class="container">
    	<div class="row justify-content-center">
        	<div class="col-md-6">
				<div class="card border-dark">
	                <div class="card-header bg-dark text-center text-light">
	                    Inserir Procedimento
	                </div>
	                <div class="card-body">
	                    <form method="POST" action="<?php echo e(route('procedures.store')); ?>">
	                        <?php echo csrf_field(); ?>
	                        <div class="form-group row align-items-center">
	                            <label for="name" class="col-sm-2 col-form-label">Nome</label>
	                            <div class="col-sm-10">
	     							<input class="form-control" id ="name" type="text" name="name" id="name">
	   	 						</div>
	                        </div>
	                        <div class="form-group row">
	                            <label for="price" class="col-sm-2 col-form-label">Preço</label>
	                            <div class="col-sm-10">
	     							<input class="form-control" type="number" name="price" id="price">
	   	 						</div>
	                        </div>
	                </div>
	                <div class="card-footer bg-secondary border-dark text-right">
	                	<div class="float-right">
	                		<a class="btn btn-info btn" role="button" aria-pressed="true" href=<?php echo e(route('procedures.index')); ?>>Voltar</a>
	                    	<button type="submit" class="btn btn-success">Inserir</button>
	                    	</form>
						</div>
	                </div>
            	</div>
          	</div>
        </div>
	</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Usuários\Gabriel\Documentos\GitHub\2019-01-atividades-Gabriel-Reis\CSI477-2019-01-atividade-pratica-002-PHP-NEW\resources\views/procedures/create.blade.php ENDPATH**/ ?>