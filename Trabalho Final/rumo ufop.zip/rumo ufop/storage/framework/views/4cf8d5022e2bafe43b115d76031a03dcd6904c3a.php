

<?php $__env->startSection('titulo', 'Professor'); ?>

<?php $__env->startSection('conteudo'); ?>

	<div class="p-3 mb-2 container mt-4">
	<div>
		<h2>Relação de Professores</h2>
	</div>
		<table class="table table-striped table-bordered table-hover table-sm table-responsive-sm">
		<thead>
		<tr>
			<th>Nome</th>
			<th>Data Inicio</th>
			<th>Data Termino</th>
			<th>Disciplina</th>
			<th>Celular</th>
			<th>Ação</th>
		</tr>
		</thead>

		<?php $__currentLoopData = $professor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td> <?php echo e($p->nome); ?> </td>
				<td> <?php echo e($p->inicio); ?> </td>
				<td> <?php echo e($p->termino); ?> </td>
				<td> <?php echo e($p->disciplina); ?> </td>
				<td> <?php echo e($p->cel); ?> </td>

				<td><a href="<?php echo e(route('professor.show', $p->id )); ?>">Exibir</a></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</table>

	<div class="float-right">
		<a class="btn btn-outline-success" role="button" aria-pressed="true" href=<?php echo e(route('professor.create')); ?>>Novo Professor</a>
	</div>

	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bc/Área de Trabalho/rumo ufop/resources/views/professor/index.blade.php ENDPATH**/ ?>