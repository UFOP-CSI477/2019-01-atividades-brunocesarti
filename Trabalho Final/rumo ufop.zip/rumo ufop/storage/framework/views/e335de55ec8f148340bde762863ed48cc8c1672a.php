

<?php $__env->startSection('titulo','Exibir Usuário'); ?>

<?php $__env->startSection('conteudo'); ?>

<br>
	<div class="container">
    	<div class="row justify-content-center">
        	<div class="col-md-6">
				<div class="card border-success">
	                <div class="card-header bg-primary text-center text-light">
	                    <label>Usuário <?php echo e($user -> name); ?></label>
	                </div>
	                <div 	>
	                	<div class="list-group">
							<label class="list-group-item d-flex justify-content-between align-items-center list-group-item-action list-group-item-secondary">Nome: <?php echo e($user->name); ?> </label>
							<label class="list-group-item d-flex justify-content-between align-items-center list-group-item-action list-group-item-secondary">Email: <?php echo e($user->email); ?> </label>
							<label class="list-group-item d-flex justify-content-between align-items-center list-group-item-action list-group-item-secondary">Nível de permissão:
								<?php if($user->type==1): ?>
									<td> Administrador </td>
								<?php elseif($user->type==2): ?>
									<td> Operador </td>
								<?php elseif($user->type==3): ?>
									<td> Paciente </td>
								<?php endif; ?>
							</label>
						</div>
					</div>
	                <div class="card-footer bg-secondary border-success text-right">
	                	<div class="d-flex justify-content-end">
	                	<a class="btn btn-primary btn-sm mr-2" role="button" aria-pressed="true" href=<?php echo e(route('users.index')); ?>>Voltar</a>
	                	<a class="btn btn-success btn-sm" role="button" aria-pressed="true" href=<?php echo e(route('users.edit',$user->id)); ?>>Editar</a>
	                	<?php
							$bool = True;

	                	foreach ($procedures as $pd)
	                		if ($pd->user_id == $user->id)
								$bool = False;

	                	foreach ($tests as $t)
	                		if ($t->user_id == $user->id && $bool = True)
								$bool = False;
	                	?>

	                	<?php if($bool == True): ?>
	                		<form method="post" action="<?php echo e(route('users.destroy',$user->id)); ?>" onsubmit="
	                			return confirm('cofirma exclusão do Usuário?');">
								<?php echo csrf_field(); ?>
								<?php echo method_field('DELETE'); ?>
								<input class="btn btn-danger btn-sm ml-2" type="submit" value="Excluir">
							</form>
						<?php endif; ?>

	                </div>
            	</div>
          	</div>
        </div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bc/Área de Trabalho/analises laboratoriais/resources/views/users/show.blade.php ENDPATH**/ ?>