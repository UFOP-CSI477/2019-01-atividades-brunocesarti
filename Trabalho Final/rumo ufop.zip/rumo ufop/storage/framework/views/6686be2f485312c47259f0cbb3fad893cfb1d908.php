<?php $__env->startSection('titulo','Editar usuário'); ?>

<?php $__env->startSection('conteudo'); ?>
		
	<br>
	<div class="container">
    	<div class="row justify-content-center">
        	<div class="col-md-7">
				<div class="card border-dark">
	                <div class="card-header bg-dark text-center text-light">
	                    Editar Usuário
	                </div>
	                <div class="card-body">
	                    <form method="post" action="<?php echo e(route('users.update', $user->id)); ?>">
							<?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
							<div class="form-group row align-items-center">
	                            <label for="name" class="col-sm-3 col-form-label">Nome</label>
	                            <div class="col-sm-9">
	     							<input class="form-control" id ="name" type="text" name="name" value="<?php echo e($user->name); ?>">	
	     						</div>
	                        </div>
	                        <div class="form-group row align-items-center">
	                            <label for="name" class="col-sm-3 col-form-label">Email</label>
	                            <div class="col-sm-9">
	                            	<input class="form-control" id ="email" type="text" name="email" value="<?php echo e($user->email); ?>">	
	                            </div>
	                        </div>
	                        <div class="form-group row align-items-center">
	                            <label for="name" class="col-sm-3 col-form-label">Senha</label>
	                            <div class="col-sm-9">
	     							<input class="form-control" id ="password" type="password" name="password">
	   	 						</div>
	                        </div>
	                        <div class="form-group row align-items-center">
	                            <label for="name" class="col-sm-3 col-form-label">Nível de permissão</label>
	                            <div class="col-sm-9">
	                            	<select class="form-control" name="type">
								    	<option value="1"
	                            			<?php if($user->type==1): ?>
								    			selected
								    		<?php endif; ?>
								    	 >Administrador</option>
								    	 <option value="2"
	                            			<?php if($user->type==2): ?>
								    			selected
								    		<?php endif; ?>
								    	 >Operador</option>
								    	 <option value="3"
	                            			<?php if($user->type==3): ?>
								    			selected
								    		<?php endif; ?>
								    	 >Paciente</option>
	                            	</select>
	   	 						</div>
	                        </div>
	                </div>
	                <div class="card-footer bg-secondary border-dark text-right">
	                	<div class="float-right">

	                		<a class="btn btn-success btn" role="button" aria-pressed="true" href=<?php echo e(route('users.show', $user->id )); ?>>Voltar</a>
							<input class="btn btn-primary" type="submit" name="btnSalvar" value="Editar">
						</form>
						</div>
	                </div>
            	</div>
          	</div>
        </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Usuários\Gabriel\Documentos\GitHub\2019-01-atividades-Gabriel-Reis\CSI477-2019-01-atividade-pratica-002-PHP\resources\views/users/edit.blade.php ENDPATH**/ ?>